# MyMC
Free Bootstrap template for Minecraft servers.

[Click here for a demo] (http://rodymol123.github.io/MyMC/)

##Pages

* Homepage
* Rules
* Staff
* Vote
* (+ link to your servershop)

## Screenshots
![Example](https://xtrada.nl/dist/img/mymc.png)

## Bugs and Issues

Have a bug or an issue with this template? Open an issue or send us a message on [https://xtrada.nl/en/bug-report] (http://xtrada.nl/en/bug-report)

## Creator

MyMC is maintained by **Rody Molenaar** from [Xtrada Nederland] (https://xtrada.nl/en/).

* https://twitter.com/rodymolenaar
* https://github.com/rodymol123

Follow [@XtradaNL] (https://twitter.com/XtradaNL) for more cool themes and templates!


## Copyright and License

Copyright 2015 Xtrada Nederland. Code released under the [Apache 2.0](http://www.apache.org/licenses/LICENSE-2.0) license.